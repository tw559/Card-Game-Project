First input must be a positive number.
Second input must be the name of a pack file: a file containing at least 8*(number of players) lines which can be parsed as integers. If the pack does not allow for a winning hand, i.e. no number occurs at least four times, the pack will be read as valid but no winner will emerge.
